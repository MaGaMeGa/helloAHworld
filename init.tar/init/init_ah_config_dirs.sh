#!/bin/sh 

# clouds.conf should contain the names of the clouds, 
# single continues alphanumerical caracters representing the cloud names
# each name must be not more then 48 characters
# each name but the last one should be terminated by a newline character

CLOUDS=$(cat clouds.conf)
SYSTEMS=$(cat systems.txt)

for cloud in ${CLOUDS}
do
	CLOUD_BASE_DIR="/etc/arrowhead/clouds/${cloud}/conf.d/cores"
	if [ ! -d ${CLOUD_BASE_DIR} ]; then
		mkdir -p ${CLOUD_BASE_DIR}
		
		for system in ${SYSTEMS}
		do
			mkdir -p "${CLOUD_BASE_DIR}/${system}"
		done
	fi
done

#TC1_DIR=$(ls /etc/arrowhead/clouds/tc1/conf.d/cores/)
#TC2_DIR=$(ls /etc/arrowhead/clouds/tc2/conf.d/cores/)

#for i in $TC1_DIR 
#	do
#		if [ -h  /etc/arrowhead/clouds/tc1/conf.d/cores/$i/ah.jar ]
#			then
#				 echo $i-jar allready linked...
#			else
#				ln -s /usr/share/arrowhead/cores/$i/*.jar /etc/arrowhead/clouds/tc1/conf.d/cores/$i/ah.jar
#		fi
#	done


#for i in $TC2_DIR 
#	do
#		if [ -h  /etc/arrowhead/clouds/tc2/conf.d/cores/$i/ah.jar ]
#			then
#				 echo $i-jar allready linked...
#			else
#				ln -s /usr/share/arrowhead/cores/$i/*.jar /etc/arrowhead/clouds/tc2/conf.d/cores/$i/ah.jar
#		fi
#	done

