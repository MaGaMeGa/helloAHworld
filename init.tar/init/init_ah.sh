1-init_ah_config_dirs.sh
2-init_ah_bin_dirs.sh
3-init_ah_certs_dirs.sh
4-copy_jars.sh
5-init_jar_links.sh
6-copy_app_default_configs.sh
