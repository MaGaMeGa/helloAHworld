#!/bin/sh

BASE_DIR="/usr/share/arrowhead"
mkdir -p ${BASE_DIR}

CERTS_DIR="${BASE_DIR}/certs"

mkdir -p ${CERTS_DIR}

CLOUDS=$(cat clouds.conf)
SYSTEMS=$(cat systems.txt)

for cloud in ${CLOUDS}
do
	for system in ${SYSTEMS}
	do
		mkdir -p "${CERTS_DIR}/${cloud}/${system}"
	done
done
