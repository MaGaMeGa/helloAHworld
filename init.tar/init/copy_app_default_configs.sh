#!/bin/sh

BASE_DIR=$( cat release.conf )
CONF_BASE_DIR="/etc/arrowhead/clouds"

CLOUDS=$(cat clouds.conf)
SYSTEMS=$(cat systems.txt)

if [ -d ${BASE_DIR} ];then

	for cloud in ${CLOUDS}
	do
		for system in ${SYSTEMS}
		do
			DST_DIR="${CONF_BASE_DIR}/${cloud}/conf.d/cores/${system}"
			APP_PROPS=$( find "${BASE_DIR}/${system}" -name "application.properties" )
			LOG_PROPS=$( find "${BASE_DIR}/${system}" -name "log4j2.xml" )
			cp "${APP_PROPS}" "${DST_DIR}"
			cp "${LOG_PROPS}" "${DST_DIR}"
		done
	done
fi
