#!/bin/sh

BASE_DIR=$( cat release.conf )
CORS_DIR="/usr/share/arrowhead/cores"
SYSTEMS=$(cat systems.txt)

if [ -d ${BASE_DIR} ];then

	for system in ${SYSTEMS}
	do
		JAR=$( find "${BASE_DIR}/${system}" -name "*.jar" )
		cp "${JAR}" "${CORS_DIR}/${system}"
	done
fi
