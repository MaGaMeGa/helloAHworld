#!/bin/sh -x

CONF_BASE_DIR="/etc/arrowhead/clouds"
JAR_BASE_DIR="/usr/share/arrowhead/cores"
CLOUDS=$(cat clouds.conf)
SYSTEMS=$(cat systems.txt)

for cloud in ${CLOUDS}
do
	for system in ${SYSTEMS}
	do
		if [ -h "${CONF_BASE_DIR}/${cloud}/conf.d/cores/${system}/ah.jar" ]
		then
			 echo "${system}-jar allready linked..."
		else
			ln -s ${JAR_BASE_DIR}/${system}/*.jar ${CONF_BASE_DIR}/${cloud}/conf.d/cores/${system}/ah.jar
		fi
	done
done
