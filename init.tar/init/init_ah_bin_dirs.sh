#!/bin/sh

BASE_DIR="/usr/share/arrowhead"
mkdir -p ${BASE_DIR}

CORES_DIR="${BASE_DIR}/cores"

mkdir -p ${CORES_DIR}

SYSTEMS=$(cat systems.txt)
for system in ${SYSTEMS}
do
	mkdir "${CORES_DIR}/${system}"
done

