#!/bin/sh

FILE=$1

CONF_BASE_DIR="/etc/arrowhead/clouds"
CLOUDS=$(cat clouds.conf)
SYSTEMS=$(cat systems.txt)

for cloud in ${CLOUDS}
do
	for system in ${SYSTEMS}
	do
		cp  ${FILE} ${CONF_BASE_DIR}/${cloud}/conf.d/cores/${system}	
	done
done
