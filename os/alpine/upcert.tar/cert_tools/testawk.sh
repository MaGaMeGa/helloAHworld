#!/bin/sh


FILE="cloud_certs.conf"

CLOUDS=$(cat ../clouds.conf)
SYSTEMS=$(cat ../systems.txt)

for cloud in ${CLOUDS}
do
	for system in ${SYSTEMS}
	do
		while read line
			do
				echo $line | awk -v c=${cloud} '$1 == c {print $0}' | awk -v s=${system} '$2 == s {print "c="$1 " s="$2 " ip="$3}'
			done<${FILE}	
	done
done
