#!/bin/sh


############################################
###                                      ###
### intercloud level certificate config  ###
###                                      ###
############################################

ROOT_NAME="master"
ROOT_ALIAS="arrowhead.eu"
OPERATOR="aitia"

RELAY_ROOT_NAME="relay-master"
RELAY_ROOT_ALIAS="${RELAY_ROOT_NAME}"
RELAY_NAME="relay1"
RELAY_ALIAS="${RELAY_NAME}"
RELAY_IP="192.168.56.1"
RELAY_TRUSTSTORE_NAME="${RELAY_NAME}.truststore"

ROOT_PASS="123456"
RELAY_ROOT_PASS="123456"
RELAY_PASS="123456"
RELAY_TRUST_PASS="123456"

BASE_DIR="/tmp/newcerts"

CONFIG=$(cat cloud_certs.conf)

##############################################
###                                        ###
### intercloud level certificate creation  ###
###                                        ###
##############################################

if [ -d ${BASE_DIR} ];then
	rm -r ${BASE_DIR}
	mkdir -p ${BASE_DIR}
else
	mkdir -p ${BASE_DIR}
fi

sh makemastercert.sh "${BASE_DIR}/${ROOT_NAME}.p12" ${ROOT_ALIAS} ${ROOT_PASS}

sh makerelaymastercert.sh \
	"${BASE_DIR}/${ROOT_NAME}.p12" \
	"${ROOT_ALIAS}"  \
	"${ROOT_PASS}" \
	"${BASE_DIR}/${RELAY_ROOT_NAME}.p12" \
	"${RELAY_ROOT_ALIAS}" \
	"${RELAY_ROOT_PASS}"

sh makerelaycert.sh \
	"${BASE_DIR}/${ROOT_NAME}.crt" \
	"${ROOT_ALIAS}"  \
	"${BASE_DIR}/${RELAY_ROOT_NAME}.p12" \
	"${RELAY_ROOT_ALIAS}" \
	"${RELAY_ROOT_PASS}" \
	"${BASE_DIR}" \
	"${RELAY_NAME}" \
	"${RELAY_PASS}" \
	"${RELAY_IP}"

sh maketruststore.sh \
	"${BASE_DIR}" \
	"${BASE_DIR}" \
	"${ROOT_NAME}" \
	"${ROOT_ALIAS}" \
	"${ROOT_PASS}" \
	"${RELAY_TRUSTSTORE_NAME}" \
	"${RELAY_TRUST_PASS}"



############################################
###                                      ###
###      cloud level certificate config  ###
###                                      ###
############################################
CLOUDS=$(cat ../clouds.conf)
SYSTEMS=$(cat ../systems.txt)

for cloud in ${CLOUDS}
do
	CLOUD_BASE_DIR="${BASE_DIR}/${cloud}"
	if [ -d ${CLOUD_BASE_DIR} ];then
		rm -r ${CLOUD_BASE_DIR}
	fi
	mkdir ${CLOUD_BASE_DIR}

	CLOUD1_NAME="${cloud}"
	CLOUD1_ALIAS="${CLOUD1_NAME}.${OPERATOR}"
	CLOUD1_TRUSTSTORE_NAME="${CLOUD1_NAME}.truststore"
	CLOUD1_GATE_TRUSTSTORE_NAME="${CLOUD1_NAME}.gate.truststore"
	CLOUD1_KS="${CLOUD_BASE_DIR}/${CLOUD1_NAME}.p12"

	CLOUD1_PASS="123456"
	CLOUD1_TRUST_PASS="123456"
	CLOUD1_GATE_TRUST_PASS="123456"

	##############################################
	###                                        ###
	### cloud level certificate creation       ###
	###                                        ###
	##############################################

	sh makecloudcert.sh \
		"${BASE_DIR}/${ROOT_NAME}.p12" \
		"${ROOT_ALIAS}" \
		"${ROOT_PASS}" \
		"${CLOUD1_KS}" \
		"${CLOUD1_ALIAS}" \
		"${CLOUD1_PASS}"

	sh makecloudtruststore.sh \
		"${CLOUD_BASE_DIR}" \
		"${CLOUD_BASE_DIR}" \
		"${CLOUD1_NAME}" \
		"${CLOUD1_ALIAS}" \
		"${CLOUD1_PASS}" \
		"${CLOUD1_TRUSTSTORE_NAME}" \
		"${CLOUD1_TRUST_PASS}"

	sh makecloudtruststore.sh \
		"${CLOUD_BASE_DIR}" \
		"${CLOUD_BASE_DIR}" \
		"${CLOUD1_NAME}" \
		"${CLOUD1_ALIAS}" \
		"${CLOUD1_PASS}" \
		"${CLOUD1_GATE_TRUSTSTORE_NAME}" \
		"${CLOUD1_GATE_TRUST_PASS}" \
		"${BASE_DIR}" \
		"${RELAY_ROOT_NAME}" \


	##############################################
	###                                        ###
	### system level certificate config        ###
	###                                        ###
	##############################################

	for system in ${SYSTEMS}
	do
		SYSTEM_BASE_DIR="${CLOUD_BASE_DIR}/${system}"
		if [ -d ${SYSTEM_BASE_DIR} ];then
			rm -r ${SYSTEM_BASE_DIR}
		fi
		mkdir ${SYSTEM_BASE_DIR}

		SEARCH_FOR="${cloud} ${system}"
		SYSIP1=$(echo "${CONFIG}" | awk -v s="${SEARCH_FOR}" '$0 ~ s {print $3}')
		
		SYS_PASS="123456"
	
		echo "sys pass : ${SYS_PASS}"
		echo "cloud pass : ${CLOUD1_PASS}"
		##	echo "${SYS_PASS}" >> "${BASE_DIR}${CLOUD1_ALIAS}.${SYSNAME}.sec" # TODO: store in gpg

		sh makesystemcert.sh \
		"${BASE_DIR}/${ROOT_NAME}.crt" \
		"${ROOT_ALIAS}" \
		"${CLOUD1_KS}" \
		"${CLOUD1_ALIAS}" \
		"${CLOUD1_PASS}" \
		"${SYSTEM_BASE_DIR}/" \
		"${system}" \
		"${SYS_PASS}" \
		"${SYSIP1}"
		
	done
done
