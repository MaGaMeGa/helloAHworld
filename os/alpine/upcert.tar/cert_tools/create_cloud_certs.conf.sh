#!/bin/sh

FILE="cloud_certs.conf"
if [ -f ${FILE} ];then
	rm ${FILE}
fi
touch ${FILE}

CLOUDS=$(cat ../clouds.conf)
SYSTEMS=$(cat ../systems.txt)

PUBLIC_IP="192.168.56.1"

for cloud in ${CLOUDS}
do
	for system in ${SYSTEMS}
	do
		echo "${cloud} ${system} ${PUBLIC_IP}" >> ${FILE}
	done
done
