#!/bin/sh


BASE_DIR="/tmp/newcerts"
TARGET_BASE_DIR="/usr/share/arrowhead/certs"

#ls -al ${BASE_DIR} | awk '$1 ~ /^-/ { print "cp "' ${BASE_DIR} '"/"$NF " "'${TARGET_BASE_DIR}'  }'

ls -al ${BASE_DIR} | awk '$1 ~ /^-/ { print $NF }'
CLOUDS=$(cat ../clouds.conf)
SYSTEMS=$(cat ../systems.txt)

for cloud in ${CLOUDS}
do

	for system in ${SYSTEMS}
	do
		echo ...		
	done
done

