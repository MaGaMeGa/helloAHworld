#!/bin/sh

CLOUDS_CONF_PATH=".."
CLOUDS_CONF="clouds.conf"
CLOUDS=$(cat ${CLOUDS_CONF_PATH}/${CLOUDS_CONF})

DB_SCRIPTS_TEMPLATES_PATH="."
DB_SCRIPTS_TEMPLATES_DIR="${DB_SCRIPTS_TEMPLATES_PATH}/db_scripts_template"

for cloud in ${CLOUDS}
do
	CLOUD_DB_SCRIPTS="${cloud}_db_scripts"
	mkdir ${CLOUD_DB_SCRIPTS}

	cp ${DB_SCRIPTS_TEMPLATES_DIR}/* ${CLOUD_DB_SCRIPTS}

	CREATE_FILE="${CLOUD_DB_SCRIPTS}/create_${cloud}-arrowhead_tables.sql"
	mv ${CLOUD_DB_SCRIPTS}/create_xxx-arrowhead_tables.sql ${CREATE_FILE}

 	sed -i "s/xxx-arrowhead/${cloud}-arrowhead/g" ${CLOUD_DB_SCRIPTS}/*
done
