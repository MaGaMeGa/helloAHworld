#!/bin/sh

apk update && upgrade
apk add mariadb mariadb-common mariadb-client

rc -s mariadb stop
/etc/init.d/mariadb setup
sed -i 's/skip-networking/#skip-networking/' /etc/my.cnf.d/mariadb-server.cnf
sed -i 's/#bind-address/bind-address/' /etc/my.cnf.d/mariadb-server.cnf
echo "port=3306" >> /etc/my.cnf.d/mariadb-server.cnf
openrc -s mariadb start
mysql -u root < setdbrootpass.sql

mysql_secure_installation
