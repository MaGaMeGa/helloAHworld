﻿echo "starting to install choco"

iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))

echo "choco installed"