﻿
echo "CreateArrowheadVM started ..."

$VIRTUAL_MACHINE_NAME=$args[0]
$WORKING_DIR=$args[1]

echo "working dir = ${WORKING_DIR}"

md "${WORKING_DIR}\VirtualBox"
cd "${WORKING_DIR}\VirtualBox"

md "${VIRTUAL_MACHINE_NAME}"

echo "Starting to download Alpine Os image ..."
curl -o alpine-3.13.2-x86_64.iso http://dl-cdn.alpinelinux.org/alpine/v3.13/releases/x86_64/alpine-virt-3.13.2-x86_64.iso

echo "Alpine Os iamge downloaded"

echo "Starting Virtual Machine creation ..."
VBoxManage createhd --filename ./$VIRTUAL_MACHINE_NAME/"${VIRTUAL_MACHINE_NAME}.vdi" --size 8192
VBoxManage createvm --name "${VIRTUAL_MACHINE_NAME}" --ostype Linux26_64 --register
VBoxManage modifyvm "${VIRTUAL_MACHINE_NAME}" --memory 1024 --cpus 1 --acpi on --pae off --hwvirtex on --nestedpaging on --rtcuseutc on --vram 16 --audio none --accelerate3d off --accelerate2dvideo off --usb off
VBoxManage modifyvm "${VIRTUAL_MACHINE_NAME}" --boot1 dvd --boot2 disk --boot3 none --boot4 none
VBoxManage storagectl "${VIRTUAL_MACHINE_NAME}" --name "IDE" --add ide
VBoxManage storagectl "${VIRTUAL_MACHINE_NAME}" --name "SATA" --add sata
VBoxManage storageattach "${VIRTUAL_MACHINE_NAME}" --storagectl "SATA" --port 0 --device 0 --type hdd --medium ./"${VIRTUAL_MACHINE_NAME}"/"${VIRTUAL_MACHINE_NAME}.vdi"
VBoxManage storageattach "${VIRTUAL_MACHINE_NAME}" --storagectl "IDE" --port 1 --device 0 --type dvddrive --medium alpine-3.13.2-x86_64.iso
VBoxManage startvm "${VIRTUAL_MACHINE_NAME}"