﻿

$VIRTUAL_MACHINE_NAME=$args[0]
VBoxManage storageattach "${VIRTUAL_MACHINE_NAME}" --storagectl "IDE" --port 1 --device 0 --type dvddrive --medium emptydrive
VBoxManage startvm "${VIRTUAL_MACHINE_NAME}"