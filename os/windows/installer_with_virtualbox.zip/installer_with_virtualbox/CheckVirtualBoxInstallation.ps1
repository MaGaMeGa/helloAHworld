﻿echo "starting checking Virtualbox installation"

VboxManage -v > vbmv.tmp

echo "finished checking Virtualbox installation"