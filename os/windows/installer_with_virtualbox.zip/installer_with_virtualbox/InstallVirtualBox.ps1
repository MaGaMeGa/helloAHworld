﻿echo "started virtualbox installation script"

choco install virtualbox

echo "finished virtualbox installation script"