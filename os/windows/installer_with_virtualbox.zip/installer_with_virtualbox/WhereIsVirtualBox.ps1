﻿$vbox_msi = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment' VBOX_MSI_INSTALL_PATH -ea 0 | Select-Object -expand VBOX_MSI_INSTALL_PATH
    if ($vbox_msi -and $vbox_msi.EndsWith('\')) { $vbox_msi = $vbox_msi -replace '.$' }

    Write-Verbose 'Checking VBOX_MSI_INSTALL_PATH'
    if ( $installLocation = $vbox_msi ) {
        if (Test-Path $installLocation) { return $installLocation }
    }

    Write-Verbose 'Checking Get-AppInstallLocation'
    if ( $installLocation = Get-AppInstallLocation 'virtualbox') { return $installLocation }