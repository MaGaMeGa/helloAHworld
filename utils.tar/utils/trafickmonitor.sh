#!/bin/sh

tcpdump -vvv -i lo 'dst portrange 8000-19999' > hello_ic_test_dump.log
