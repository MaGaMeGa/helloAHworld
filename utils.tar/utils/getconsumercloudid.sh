mysql -uroot -p -e 
