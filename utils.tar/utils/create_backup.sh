find /etc/arrowhead/ -name "*.properties" | awk '{print "cp " $0 " " $0 ".bk" }' | sh
