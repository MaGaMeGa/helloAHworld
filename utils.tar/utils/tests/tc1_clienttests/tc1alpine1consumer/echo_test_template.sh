#!/bin/sh

curl -v -s --insecure --cert-type P12 --cert tc1alpine1consumer.p12:123456 -X GET https://127.0.0.1:18443/serviceregistry/echo
