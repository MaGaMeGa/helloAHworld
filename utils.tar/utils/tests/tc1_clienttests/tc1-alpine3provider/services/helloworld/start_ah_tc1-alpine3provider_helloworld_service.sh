#!/bin/sh

SYSTEM_NAME="tc1-alpine3provider"
SYSTEM_PORT=19903
SERVER_PATH="/home/sysop/utils/tests/tc1_clienttests/tc1-alpine3provider/services/helloworld"

cd "${SERVER_PATH}"

openssl s_server -key "${SYSTEM_NAME}-key.pem" -pass pass:123456 -cert  "${SYSTEM_NAME}.pem" -accept $SYSTEM_PORT -WWW -msg -Verify 2 > server.log
