#!/bin/sh

mysql -uroot -p -e "use tc1-arrowhead; select id from cloud where name = 'testcloud2'; " | sed -n 2p
