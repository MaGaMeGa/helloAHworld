#!/bin/sh

touch /tmp/update_hw.ser

while [ -f /tmp/update_hw.ser ]
	do
		sed "s/*** w/*$( date)* w/" hw.template > hw.date
		mv hw.date helloworld
		sleep 0.5s
	done

echo update hw service is over...
