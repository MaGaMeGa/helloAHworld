#!/bin/sh

SYSTEM_NAME="tc2-ap-3"
SYSTEM_PORT=9903
SERVER_PATH="/home/sysop/utils/tests/clienttests/tc2-ap-3/services/helloworld"

cd "${SERVER_PATH}"

openssl s_server -key "${SYSTEM_NAME}-key.pem" -pass pass:123456 -cert  "${SYSTEM_NAME}.pem" -accept $SYSTEM_PORT -WWW -msg -Verify 2 > server.log
