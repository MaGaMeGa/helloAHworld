#!/bin/sh

curl -v -s --insecure --cert-type P12 --cert /usr/share/arrowhead/certificates/testcloud2/sysop.p12:123456 -X GET https://127.0.0.1:8443/serviceregistry/echo
