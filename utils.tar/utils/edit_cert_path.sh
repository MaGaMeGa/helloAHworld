#!/bin/sh -x

DIR=$(ls /etc/arrowhead/clouds/tc1/conf.d/cores/)

for i in $DIR
	do
		cd /etc/arrowhead/clouds/tc1/conf.d/cores/$i
		sed  -i "s%key-store=classpath:certificates%key-store=file:/etc/arrowhead/clouds/tc1/conf.d/cores/$i%g" application.properties
	done
