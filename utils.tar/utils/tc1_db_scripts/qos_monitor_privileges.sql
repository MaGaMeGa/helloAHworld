USE `tc1-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_intra_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_intra_ping_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_intra_ping_measurement_log` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_intra_ping_measurement_log_details` TO 'qos_monitor'@'localhost';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_direct_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_direct_ping_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_direct_ping_measurement_log` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_direct_ping_measurement_log_details` TO 'qos_monitor'@'localhost';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_relay_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_relay_echo_measurement` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_relay_echo_measurement_log` TO 'qos_monitor'@'localhost';

GRANT SELECT ON `tc1-arrowhead`.`system_` TO 'qos_monitor'@'localhost';
GRANT SELECT ON `tc1-arrowhead`.`cloud` TO 'qos_monitor'@'localhost';
GRANT SELECT ON `tc1-arrowhead`.`relay` TO 'qos_monitor'@'localhost';
GRANT SELECT ON `tc1-arrowhead`.`cloud_gatekeeper_relay` TO 'qos_monitor'@'localhost';
GRANT SELECT ON `tc1-arrowhead`.`cloud_gateway_relay` TO 'qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`logs` TO 'qos_monitor'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_intra_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_intra_ping_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_intra_ping_measurement_log` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_intra_ping_measurement_log_details` TO 'qos_monitor'@'%';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_direct_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_direct_ping_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_direct_ping_measurement_log` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_direct_ping_measurement_log_details` TO 'qos_monitor'@'%';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_relay_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_relay_echo_measurement` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`qos_inter_relay_echo_measurement_log` TO 'qos_monitor'@'%';

GRANT SELECT ON `tc1-arrowhead`.`system_` TO 'qos_monitor'@'%';
GRANT SELECT ON `tc1-arrowhead`.`cloud` TO 'qos_monitor'@'%';
GRANT SELECT ON `tc1-arrowhead`.`relay` TO 'qos_monitor'@'%';
GRANT SELECT ON `tc1-arrowhead`.`cloud_gatekeeper_relay` TO 'qos_monitor'@'%';
GRANT SELECT ON `tc1-arrowhead`.`cloud_gateway_relay` TO 'qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`logs` TO 'qos_monitor'@'%';

FLUSH PRIVILEGES;