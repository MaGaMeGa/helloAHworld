USE `tc1-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'event_handler'@'localhost';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`event_type` TO 'event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`subscription` TO 'event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`subscription_publisher_connection` TO 'event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`system_` TO 'event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`logs` TO 'event_handler'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'event_handler'@'%';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`event_type` TO 'event_handler'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`subscription` TO 'event_handler'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`subscription_publisher_connection` TO 'event_handler'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`system_` TO 'event_handler'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`logs` TO 'event_handler'@'%';

FLUSH PRIVILEGES;