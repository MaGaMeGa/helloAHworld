USE `tc1-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'system_registry'@'localhost';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`device` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`system_` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`system_registry` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_definition` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_interface` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_registry` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_registry_interface_connection` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_intra_cloud` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_intra_cloud_interface_connection` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_inter_cloud` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'system_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`logs` TO 'system_registry'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'system_registry'@'%';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`device` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`system_` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`system_registry` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_definition` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_interface` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_registry` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_registry_interface_connection` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_intra_cloud` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_intra_cloud_interface_connection` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_inter_cloud` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'system_registry'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`logs` TO 'system_registry'@'%';

FLUSH PRIVILEGES;