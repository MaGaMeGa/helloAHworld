USE `tc1-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'gatekeeper'@'localhost';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`cloud` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`relay` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`system_` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_definition` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`cloud_gatekeeper_relay` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`cloud_gateway_relay` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_inter_cloud` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`foreign_system` TO 'gatekeeper'@'localhost';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`logs` TO 'gatekeeper'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'gatekeeper'@'%';

GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`cloud` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`relay` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`system_` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`service_definition` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`cloud_gatekeeper_relay` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`cloud_gateway_relay` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_inter_cloud` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`foreign_system` TO 'gatekeeper'@'%';
GRANT ALL PRIVILEGES ON `tc1-arrowhead`.`logs` TO 'gatekeeper'@'%';

FLUSH PRIVILEGES;