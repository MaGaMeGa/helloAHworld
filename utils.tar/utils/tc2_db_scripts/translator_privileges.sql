USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-translator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-translator'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-translator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-translator'@'%';

FLUSH PRIVILEGES;