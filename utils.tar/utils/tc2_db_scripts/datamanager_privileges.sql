USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-datamanager'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`dmhist_services` TO 'tc2-datamanager'@'localhost';
#GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`dmhist_files` TO 'tc2-datamanager'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`dmhist_messages` TO 'tc2-datamanager'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`dmhist_entries` TO 'tc2-datamanager'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-datamanager'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`dmhist_services` TO 'tc2-datamanager'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`dmhist_files` TO 'tc2-datamanager'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`dmhist_messages` TO 'tc2-datamanager'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`dmhist_entries` TO 'tc2-datamanager'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-datamanager'@'%';

FLUSH PRIVILEGES;
