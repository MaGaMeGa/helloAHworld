USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_intra_measurement` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_intra_ping_measurement` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_intra_ping_measurement_log` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_intra_ping_measurement_log_details` TO 'tc2-qos_monitor'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_direct_measurement` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_direct_ping_measurement` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_direct_ping_measurement_log` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_direct_ping_measurement_log_details` TO 'tc2-qos_monitor'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_relay_measurement` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_relay_echo_measurement` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_relay_echo_measurement_log` TO 'tc2-qos_monitor'@'localhost';

GRANT SELECT ON `tc2-arrowhead`.`system_` TO 'tc2-qos_monitor'@'localhost';
GRANT SELECT ON `tc2-arrowhead`.`cloud` TO 'tc2-qos_monitor'@'localhost';
GRANT SELECT ON `tc2-arrowhead`.`relay` TO 'tc2-qos_monitor'@'localhost';
GRANT SELECT ON `tc2-arrowhead`.`cloud_gatekeeper_relay` TO 'tc2-qos_monitor'@'localhost';
GRANT SELECT ON `tc2-arrowhead`.`cloud_gateway_relay` TO 'tc2-qos_monitor'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-qos_monitor'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_intra_measurement` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_intra_ping_measurement` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_intra_ping_measurement_log` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_intra_ping_measurement_log_details` TO 'tc2-qos_monitor'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_direct_measurement` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_direct_ping_measurement` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_direct_ping_measurement_log` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_direct_ping_measurement_log_details` TO 'tc2-qos_monitor'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_relay_measurement` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_relay_echo_measurement` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_inter_relay_echo_measurement_log` TO 'tc2-qos_monitor'@'%';

GRANT SELECT ON `tc2-arrowhead`.`system_` TO 'tc2-qos_monitor'@'%';
GRANT SELECT ON `tc2-arrowhead`.`cloud` TO 'tc2-qos_monitor'@'%';
GRANT SELECT ON `tc2-arrowhead`.`relay` TO 'tc2-qos_monitor'@'%';
GRANT SELECT ON `tc2-arrowhead`.`cloud_gatekeeper_relay` TO 'tc2-qos_monitor'@'%';
GRANT SELECT ON `tc2-arrowhead`.`cloud_gateway_relay` TO 'tc2-qos_monitor'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-qos_monitor'@'%';

FLUSH PRIVILEGES;