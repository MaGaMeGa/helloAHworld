USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-choreographer'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_plan` TO 'tc2-choreographer'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_action` TO 'tc2-choreographer'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_step` TO 'tc2-choreographer'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_action_step_service_definition_connection` TO 'tc2-choreographer'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_step_next_step_connection` TO 'tc2-choreographer'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_session` TO 'tc2-choreographer'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_running_step` TO 'tc2-choreographer'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_worklog` TO 'tc2-choreographer'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-choreographer'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-choreographer'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_plan` TO 'tc2-choreographer'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_action` TO 'tc2-choreographer'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_step` TO 'tc2-choreographer'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_step_service_definition_connection` TO 'tc2-choreographer'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_step_next_step_connection` TO 'tc2-choreographer'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_session` TO 'tc2-choreographer'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_running_step` TO 'tc2-choreographer'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-choreographer_worklog` TO 'tc2-choreographer'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-choreographer'@'%';

FLUSH PRIVILEGES;