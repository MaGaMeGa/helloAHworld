USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-orchestrator'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`orchestrator_store` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`foreign_system` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`orchestrator_store_flexible` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`relay` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gatekeeper_relay` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gateway_relay` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_definition` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_interface` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_reservation` TO 'tc2-orchestrator'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-orchestrator'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-orchestrator'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`orchestrator_store` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`foreign_system` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`orchestrator_store_flexible` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`relay` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gatekeeper_relay` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gateway_relay` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_definition` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_interface` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`qos_reservation` TO 'tc2-orchestrator'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-orchestrator'@'%';

FLUSH PRIVILEGES;