USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-event_handler'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`event_type` TO 'tc2-event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`subscription` TO 'tc2-event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`subscription_publisher_connection` TO 'tc2-event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-event_handler'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-event_handler'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-event_handler'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`event_type` TO 'tc2-event_handler'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`subscription` TO 'tc2-event_handler'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`subscription_publisher_connection` TO 'tc2-event_handler'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-event_handler'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-event_handler'@'%';

FLUSH PRIVILEGES;