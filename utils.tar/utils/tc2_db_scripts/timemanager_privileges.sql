USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-timemanager'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-timemanager'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-timemanager'@'%';

FLUSH PRIVILEGES;
