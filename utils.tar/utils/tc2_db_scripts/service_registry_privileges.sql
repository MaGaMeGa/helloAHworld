USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-service_registry'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_definition` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_interface` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_registry` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_registry_interface_connection` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`relay` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gatekeeper_relay` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gateway_relay` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud_interface_connection` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`orchestrator_store` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`subscription` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`subscription_publisher_connection` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_plan` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_step` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_plan_action_connection` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_action_step_connection` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_step_service_definition_connection` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_next_action_step` TO 'tc2-service_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-service_registry'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-service_registry'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_definition` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_interface` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_registry` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_registry_interface_connection` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`relay` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gatekeeper_relay` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gateway_relay` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud_interface_connection` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`orchestrator_store` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`subscription` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`subscription_publisher_connection` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_plan` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_step` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_plan_action_connection` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_action_step_connection` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_action_step_service_definition_connection` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`choreographer_next_action_step` TO 'tc2-service_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-service_registry'@'%';

FLUSH PRIVILEGES;