USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-plant_description_engine'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`pde_rule` TO 'tc2-plant_description_engine'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`plant_description` TO 'tc2-plant_description_engine'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-plant_description_engine'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-plant_description_engine'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`pde_rule` TO 'tc2-plant_description_engine'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`plant_description` TO 'tc2-plant_description_engine'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-plant_description_engine'@'%';

FLUSH PRIVILEGES;
