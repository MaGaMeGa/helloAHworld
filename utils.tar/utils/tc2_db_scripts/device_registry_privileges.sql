USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-device_registry'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`device` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-device_registry` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_definition` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_interface` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_registry` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_registry_interface_connection` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud_interface_connection` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'tc2-device_registry'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-device_registry'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-device_registry'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`device` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-device_registry` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_definition` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_interface` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_registry` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_registry_interface_connection` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud_interface_connection` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'tc2-device_registry'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-device_registry'@'%';

FLUSH PRIVILEGES;