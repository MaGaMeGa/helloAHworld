USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-configuration'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-configuration_data` TO 'tc2-configuration'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-configuration'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`tc2-configuration_data` TO 'tc2-configuration'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-configuration'@'%';

FLUSH PRIVILEGES;
