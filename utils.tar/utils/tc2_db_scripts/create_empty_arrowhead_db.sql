DROP DATABASE IF EXISTS `tc2-arrowhead`;
CREATE DATABASE `tc2-arrowhead`;
USE `tc2-arrowhead`;

-- create tables
source create_tc2-arrowhead_tables.sql

-- Set up privileges

-- Service Registry
CREATE USER IF NOT EXISTS 'tc2-service_registry'@'localhost' IDENTIFIED BY 'ZzNNpxrbZGVvfJ8';
CREATE USER IF NOT EXISTS 'tc2-service_registry'@'%' IDENTIFIED BY 'ZzNNpxrbZGVvfJ8';
source service_registry_privileges.sql

-- System Registry
CREATE USER IF NOT EXISTS 'tc2-system_registry'@'localhost' IDENTIFIED BY 'Kh12Hhgaxzo7haf';
CREATE USER IF NOT EXISTS 'tc2-system_registry'@'%' IDENTIFIED BY 'Kh12Hhgaxzo7haf';
source system_registry_privileges.sql

-- Device Registry
CREATE USER IF NOT EXISTS 'tc2-device_registry'@'localhost' IDENTIFIED BY 'iooHU87hNGUalht';
CREATE USER IF NOT EXISTS 'tc2-device_registry'@'%' IDENTIFIED BY 'iooHU87hNGUalht';
source device_registry_privileges.sql

-- Onboarding controller
CREATE USER IF NOT EXISTS 'tc2-onboarding_controller'@'localhost' IDENTIFIED BY 'JKgh1as5f6oi7aV';
CREATE USER IF NOT EXISTS 'tc2-onboarding_controller'@'%' IDENTIFIED BY 'JKgh1as5f6oi7aV';
source onboarding_controller_privileges.sql

-- Authorization
CREATE USER IF NOT EXISTS 'tc2-authorization'@'localhost' IDENTIFIED BY 'hqZFUkuHxhekio3';
CREATE USER IF NOT EXISTS 'tc2-authorization'@'%' IDENTIFIED BY 'hqZFUkuHxhekio3';
source authorization_privileges.sql

-- Orchestrator
CREATE USER IF NOT EXISTS 'tc2-orchestrator'@'localhost' IDENTIFIED BY 'KbgD2mTr8DQ4vtc';
CREATE USER IF NOT EXISTS 'tc2-orchestrator'@'%' IDENTIFIED BY 'KbgD2mTr8DQ4vtc';
source orchestrator_privileges.sql

-- Event Handler
CREATE USER IF NOT EXISTS 'tc2-event_handler'@'localhost' IDENTIFIED BY 'gRLjXbqu9YwYhfK';
CREATE USER IF NOT EXISTS 'tc2-event_handler'@'%' IDENTIFIED BY 'gRLjXbqu9YwYhfK';
source event_handler_privileges.sql

-- DataManager
CREATE USER IF NOT EXISTS 'tc2-datamanager'@'localhost' IDENTIFIED BY 'gRLjXbqu0YwYhfK';
CREATE USER IF NOT EXISTS 'tc2-datamanager'@'%' IDENTIFIED BY 'gRLjXbqu0YwYhfK';
source datamanager_privileges.sql

-- TimeManager
CREATE USER IF NOT EXISTS 'tc2-timemanager'@'localhost' IDENTIFIED BY 'xyp2XEAu5Tbc41g';
CREATE USER IF NOT EXISTS 'tc2-timemanager'@'%' IDENTIFIED BY 'xyp2XEAu5Tbc41g';
source timemanager_privileges.sql

-- Choreographer
CREATE USER IF NOT EXISTS 'tc2-choreographer'@'localhost' IDENTIFIED BY 'Qa5yx4oBp4Y9RLX';
CREATE USER IF NOT EXISTS 'tc2-choreographer'@'%' IDENTIFIED BY 'Qa5yx4oBp4Y9RLX';
source choreographer_privileges.sql

-- Configuration
CREATE USER IF NOT EXISTS 'tc2-configuration'@'localhost' IDENTIFIED BY 'yRLjX2qA0YwYhzU';
CREATE USER IF NOT EXISTS 'tc2-configuration'@'%' IDENTIFIED BY 'yRLjX2qA0YwYhzU';
source configuration_privileges.sql

-- Gatekeeper
CREATE USER IF NOT EXISTS 'tc2-gatekeeper'@'localhost' IDENTIFIED BY 'fbJKYzKhU5t8QtT';
CREATE USER IF NOT EXISTS 'tc2-gatekeeper'@'%' IDENTIFIED BY 'fbJKYzKhU5t8QtT';
source gatekeeper_privileges.sql

-- Gateway
CREATE USER IF NOT EXISTS 'tc2-gateway'@'localhost' IDENTIFIED BY 'LfiSM9DpGfDEP5g';
CREATE USER IF NOT EXISTS 'tc2-gateway'@'%' IDENTIFIED BY 'LfiSM9DpGfDEP5g';
source gateway_privileges.sql

-- Certificate Authority
CREATE USER IF NOT EXISTS 'tc2-certificate_authority'@'localhost' IDENTIFIED BY 'FsdG6Kgf9QpPfv2';
CREATE USER IF NOT EXISTS 'tc2-certificate_authority'@'%' IDENTIFIED BY 'FsdG6Kgf9QpPfv2';
source certificate_authority_privileges.sql

-- QoS Monitor
CREATE USER IF NOT EXISTS 'tc2-qos_monitor'@'localhost' IDENTIFIED BY 'RLY3UEx6nx4kSXy';
CREATE USER IF NOT EXISTS 'tc2-qos_monitor'@'%' IDENTIFIED BY 'RLY3UEx6nx4kSXy';
source qos_monitor_privileges.sql

-- Translator
CREATE USER IF NOT EXISTS 'tc2-translator'@'localhost' IDENTIFIED BY 'wozYpV58G0HUkbL';
CREATE USER IF NOT EXISTS 'tc2-translator'@'%' IDENTIFIED BY 'wozYpV58G0HUkbL';
source translator_privileges.sql

-- Plant Description Engine
CREATE USER IF NOT EXISTS 'tc2-plant_description_engine'@'localhost' IDENTIFIED BY 'ivJ2y9qWCpTmzr0';
CREATE USER IF NOT EXISTS 'tc2-plant_description_engine'@'%' IDENTIFIED BY 'ivJ2y9qWCpTmzr0';
source plant_description_engine_privileges.sql