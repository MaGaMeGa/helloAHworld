USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-gateway'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-gateway'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-gateway'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-gateway'@'%';

FLUSH PRIVILEGES;
