USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-authorization'@'localhost';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud_interface_connection` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`relay` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gatekeeper_relay` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gateway_relay` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_definition` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_interface` TO 'tc2-authorization'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-authorization'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-authorization'@'%';

GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_intra_cloud_interface_connection` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`authorization_inter_cloud_interface_connection` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`system_` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`relay` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gatekeeper_relay` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`cloud_gateway_relay` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_definition` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`service_interface` TO 'tc2-authorization'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-authorization'@'%';

FLUSH PRIVILEGES;