#!/bin/sh

USER=$1

sed -i "s/$USER/tc2-$USER/g" /home/sysop/utils/tc2_db_scripts/${USER}_privileges.sql
