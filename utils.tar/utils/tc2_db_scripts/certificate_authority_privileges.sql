USE `tc2-arrowhead`;

REVOKE ALL, GRANT OPTION FROM 'tc2-certificate_authority'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-certificate_authority'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`ca_certificate` TO 'tc2-certificate_authority'@'localhost';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`ca_trusted_key` TO 'tc2-certificate_authority'@'localhost';

REVOKE ALL, GRANT OPTION FROM 'tc2-certificate_authority'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`logs` TO 'tc2-certificate_authority'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`ca_certificate` TO 'tc2-certificate_authority'@'%';
GRANT ALL PRIVILEGES ON `tc2-arrowhead`.`ca_trusted_key` TO 'tc2-certificate_authority'@'%';

FLUSH PRIVILEGES;
