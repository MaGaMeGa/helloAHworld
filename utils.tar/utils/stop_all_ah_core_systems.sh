#!/bin/sh

netstat -tlpn | awk '$0 ~/java/ { print $NF }' | awk -F '/' '{ print "kill -9 " $1 }' | sh 
