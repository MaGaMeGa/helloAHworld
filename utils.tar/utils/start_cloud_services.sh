#!/bin/sh

CLOUD_NAME=$1
SRC=silent_start.sh

DIRS=$( cat  /home/sysop/utils/s.txt )

for i in $DIRS
 	do
		if [ -f  /etc/arrowhead/clouds/$CLOUD_NAME/conf.d/cores/$i/$SRC ]
			then
				cd /etc/arrowhead/clouds/$CLOUD_NAME/conf.d/cores/$i
				nohup sh $SRC 1>/dev/null 2>/dev/null &
				echo starting $CLOUD_NAME - $i ...
				sleep 60s
		fi
	done
